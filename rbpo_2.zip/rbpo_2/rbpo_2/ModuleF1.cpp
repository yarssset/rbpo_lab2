module student_1bib21065_Lab2_Variant26_Task1:F1;
#include <cmath>

namespace RBPO {
	namespace Lab2 {
		namespace Variant26 {
			namespace Task4 {
				double f1(double);
			};
		};
	};
};

double RBPO::Lab2::Variant26::Task4::f1(double x) {
	return 1 / (sqrt(x + 2));
};