module student_1bib21065_Lab2_Variant26_Task1:A;

namespace RBPO {
	namespace Lab2 {
		namespace Variant26 {
			namespace Task4 {
				double a(long);
			};
		};
	};
};

double RBPO::Lab2::Variant26::Task4::a(long n) {
	return (-1) ^ n * (1 - ((n + 1) ^ 2 / (n + 2) ^ 2));
};