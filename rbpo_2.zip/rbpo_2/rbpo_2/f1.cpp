module;
#include <cmath>

module student_1bib21065_Lab2_Variant26_Task1;


namespace RBPO {
	namespace Lab2 {
		namespace Variant26 {
			namespace Task3 {
				double f1(double);
			};
		};
	};
};

double RBPO::Lab2::Variant26::Task3::f1(double x) {
	return 1 / (sqrt(x + 2));
}